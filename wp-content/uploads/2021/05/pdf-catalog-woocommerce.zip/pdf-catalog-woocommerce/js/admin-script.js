jQuery( document ).ready(function() {
	jQuery(function() {
        jQuery('.gmpcp-color-field').wpColorPicker();
    });
});