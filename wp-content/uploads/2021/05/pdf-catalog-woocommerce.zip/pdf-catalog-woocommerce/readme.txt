=== PDF Catalog Woocommerce ===
Tested up to: 5.7
Tags: Woocommerce Catalog PDF, Woocommerce PDF, Woocommerce  Catalog
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

**Woocommerce Catalog PDF** Customer can be download your single product page catelog or category wise or all product catelog can be download by  [Woocommerce Catalog PDF](https://en.wikipedia.org/wiki/WooCommerce)

[Demo](https://codesmade.com/demo/product/album/)

**Woocommerce PDF Catalog** make to download all product dyanmic in pdf.

**Woocommerce PDF catalog** can be use of offline customer to product all information with price , product description, sku with images . there is nice layout of pdf to make attaractive catalog.

PDF For woocommerce product can be export as pdf in shop , category and single product page. **add pdf download option** in woocommerce pages to easy way to get product information which product you want to get information in **Woocommerce Catalog PDF**.

= Features =

&#9989; One Click installation
&#9989; Shop and Category wise make Catelog pdf
&#9989; Signle Product page on make catelog 
&#9989; Customize Background and Text Color
&#9989; Easy To use
&#9989; Multiple Location for Show Button

#### How to use Woocommerce Catalog PDF
Go to admin in **Woo Catalog PDF** there is two tab with show button on category page and single product page just need to enable



